// import another class
import Bingo from "./Bingo.js";

// kickstart the app by calling the constructor via the `new` keyword
const bingo = new Bingo();
